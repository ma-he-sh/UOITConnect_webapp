<?php
session_start();
/*
* Retireve user info for the interface
*/
 $userID   = $_SESSION['user_ID'];
 $userName = $_SESSION['user_name'];
?>